import glpk from './glpk.js';

export default () => glpk();
