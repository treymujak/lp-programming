# glpk.js

GNU Linear Programming Kit for Javascript

[Live demo](http://hgourvest.github.io/glpk.js/)
